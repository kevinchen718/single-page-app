import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TaxCalcComponent } from './tax-calc/tax-calc.component';
import { StaffListComponent } from './staff-list/staff-list.component';
import { NestedMenuComponent } from './nested-menu/nested-menu.component';

@NgModule({
  declarations: [
    AppComponent,
    TaxCalcComponent,
    StaffListComponent,
    NestedMenuComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    MatMenuModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
