export interface Tax{
    income : number
    taxRate: number
    tax: number
}