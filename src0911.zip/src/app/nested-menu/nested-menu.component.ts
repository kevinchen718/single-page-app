import { Component, OnInit } from '@angular/core';
import { NestedMenuModule } from './nested-menu.module';

@Component({
  selector: 'app-nested-menu',
  templateUrl: './nested-menu.component.html',
  styleUrls: ['./nested-menu.component.scss']
})
export class NestedMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}


